<template>
    <div>
 <slot></slot>
    </div>
</template>



<style scoped>
 div{
    margin: 2rem auto;
    max-width: 40rem;
    padding: 1rem;
    border-radius: 12px;
    box-shadow: 0 2px 10px darkkhaki;
 }
</style>