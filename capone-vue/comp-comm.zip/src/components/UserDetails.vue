<template>
  <div class="component">
    <h3>User Details : {{ switchName() }}</h3>
  </div>
</template>

<script>
export default{
    props:['myName'],
    methods:{
        switchName(){
            return this.myName.split('').reverse().join('')
        }
    }
}
</script>
<style scoped>
div {
  background-color: lightcoral;
}
</style>
