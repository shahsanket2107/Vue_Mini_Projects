<template>
  <div class="component">
    <h3>User Edit :{{ userAge }}</h3>
  </div>
</template>

<script>
export default {
  props:['userAge']
}

</script>
<style scoped>
div {
  background-color: lightgreen;
}
</style>
