
new Vue({
    el: '#app',
    data:{
        counter:0,
        secondCounter:0
     },
    computed:{
    output:function(){
        console.log('computed');
        return this.counter > 5 ? 'Greater 5' : 'Smaller than 5'
    }
    } ,
    methods: {
        result(){
            console.log('method');
            return this.counter > 5 ? 'Greater 5' : 'Smaller than 5'
        }
    }
})