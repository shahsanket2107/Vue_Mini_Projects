<template>
    <div>
        <h1>The Home Page</h1>
        <hr>
         
    </div>
</template>