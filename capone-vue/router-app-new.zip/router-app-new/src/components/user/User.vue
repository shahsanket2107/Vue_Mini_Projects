<template>
    <div>
    <h1>The User Page</h1>

<button @click="navigate">home</button>
</div>
</template>
 
<script>
export default{
    methods:{
        navigate(){
            this.$router.push('/')
        }
    }
}
</script>