<template>
<p>welcome to VueJS</p>
</template>

<script>

</script>

<style>
</style>
